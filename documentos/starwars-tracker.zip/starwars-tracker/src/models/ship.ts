export interface IShip {
    Name: string;
    Description: string;
    Foto: string;
}