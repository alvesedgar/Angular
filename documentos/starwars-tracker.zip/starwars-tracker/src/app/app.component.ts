import {Component} from '@angular/core';
import { IShip } from '../models/ship';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  ships: Array<IShip> = [

    { Name: 'Azure Angel II', Foto: '', Description: 'Azure Angel II teste'  },
    { Name: 'Corellian Corvette', Foto: '', Description: 'Corellian Corvette' },
    { Name: 'Death Star', Foto: '', Description: 'Death Star' },
    { Name: 'Ebon Hawk', Foto: '', Description: 'Ebon Hawk' },
    { Name: 'Geonosian Solar Sailer', Foto: '', Description: 'Geonosian Solar Sailer' },
    { Name: 'The Ghost', Foto: '', Description: 'The Ghost' },
    { Name: 'Imperial Landing Craft', Foto: '', Description: 'Imperial Landing Craft' },
    { Name: 'Lambda-class Shuttle', Foto: '', Description: 'Lambda-class Shuttle' },
    { Name: 'Millennium Falcon', Foto: '', Description: 'Millennium Falcon' },
    { Name: 'Moldy Crow', Foto: '', Description: 'Moldy Crow' },
    { Name: 'Naboo Royal Cruiser', Foto: '', Description: 'Naboo Royal Cruiser' },
    { Name: 'Naboo Royal Starship', Foto: '', Description: 'Naboo Royal Starship' },
    { Name: 'Naboo Star Skiff', Foto: '', Description: 'Naboo Star Skiff' },

  ];

  selectedShip: IShip = { Name: 'Azure Angel II', Foto: '', Description: 'Azure Angel II teste'  };

  constructor() {}

  setSelectedShip(data: IShip) {
    this.selectedShip = data;
  }


}
